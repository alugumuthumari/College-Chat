make-chatterbot
===============

aiml/
-----

The aiml directory is where AIML files are stored. The `standard/` directory
contains the patterns loaded by default. New files can be included in `aiml/`
as well.
